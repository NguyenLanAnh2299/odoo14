This module allows you to define connections to foreign databases using ODBC,
Firebird, Oracle Client or SQLAlchemy.
