To configure this module, you need to:

#. Database sources can be configured in Settings > Technical >
   Database Structure > Data sources.
