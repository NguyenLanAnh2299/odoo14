* Daniel Reis <dreis.pt@hotmail.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Dave Lasley <dave@laslabs.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* David Alonso <david.alonso@solvos.es>
