To install this module, you need to:

* Install ``libmysqlclient-dev`` package (``default-libmysqlclient-dev`` on Debian)
* Install ``sqlalchemy`` and ``mysqlclient`` python libraries
