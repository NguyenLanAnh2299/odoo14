from . import openacademy
from . import partner
from . import wizard
